# AlgorithmAnalysisExercises

1. [Missing Patient Problem](MissingPatientProblem)
2. [Hungarian Folk Dance](BankOfficeProblem)
3. [Bank Office Problem](HungarianFolkDance)
4. [Phone Operator Problem](PhoneOperatorProblem)
5. [Optimal Binary Search Tree](OptimalBinarySearchTree)
6. [Complete Binary Tree Min Path](CompleteBinaryTreeMinPath)
 
