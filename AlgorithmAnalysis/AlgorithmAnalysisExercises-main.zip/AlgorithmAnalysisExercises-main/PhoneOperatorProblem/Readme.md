# Phone Operator Problem


## Question

A phone operator answering n phones
Each phone i has xi people waiting in line for their calls to be answered.
Phone operator needs to answer the phone with the largest number of people waiting in line.
New calls come continuously, and some people hang up after waiting.

