# AlgorithmExercises

Here are some algorithm questions solved using        
dynamic programming, greedy algorithm, recursive algorithm ---> FindSumPath     
heap sort --> PhoneOperatorProblem               
insertion sort --> BankOfficeProblem    
partition --> MissingPatientProblem     
quick sort --> HungarianFolkDance     
